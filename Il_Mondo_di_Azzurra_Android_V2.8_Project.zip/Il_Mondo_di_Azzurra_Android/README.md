# Il Mondo di Azzurra — Android V2.8

Progetto Android che incorpora la versione HTML del gioco in una WebView locale.

- Landscape obbligatorio
- Fullscreen/immersive
- Nessuna barra Chrome
- Contenuto locale incluso nell'APK
- JavaScript + local storage abilitati
- Build APK tramite GitHub Actions

Per compilare: caricare questa cartella in un repository GitHub e avviare l'azione **Build APK**.
